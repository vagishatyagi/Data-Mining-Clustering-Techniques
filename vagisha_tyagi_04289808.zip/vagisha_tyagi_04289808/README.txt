Steps to run the file-
1) dataset1.csv, dataset2.csv, project_dataset1.R and project_dataset2.R should be in the same directory.
2) For dataset1 results RUN->$Rscript project_dataset1.R
3)For dataset2 results RUN->$Rscript project_dataset2.R
Results as per report will be observed.

NOTE1: Please check the folder to see the generated plots from project_dataset1.R of all 4 clustering methods

NOTE2: when running second script, installing broom packge in r might stuck and wait for a input. If this happen, just type "q" to continue. Or if you encounter problem in installing broom, try running the script again and following help in install packages.




